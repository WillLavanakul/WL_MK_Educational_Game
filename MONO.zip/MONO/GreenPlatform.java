import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GreenPlatform here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GreenPlatform extends Actor
{
    //green in hexa: 00ff00
    /**
     * Act - do whatever the GreenPlatform wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
