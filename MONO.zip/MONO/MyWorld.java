import greenfoot.*;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        super(800, 800, 1); 
        Character char1 = new Character();
        addObject(char1, 0, 0);
        Platform platform1 = new Platform(50, 200);
        Platform platform2 = new Platform(50, 200);
        Platform platform3 = new Platform(50, 200);
        addObject(platform1, 100, 200);
        addObject(platform2, 350, 300);
        addObject(platform3, 600, 400);
        
    }
}