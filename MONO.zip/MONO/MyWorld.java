import greenfoot.*;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    /**
     * 
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        super(800, 800, 1); 
        Character char1 = new Character();
        addObject(char1, 0, 0);
        RedPlatform red1 = new RedPlatform();
        BluePlatform blue1 = new BluePlatform();
        GreenPlatform green1 = new GreenPlatform();
        BluePlatform blue2 = new BluePlatform();
        BluePlatform blue3 = new BluePlatform();
        BluePlatform blue4 = new BluePlatform();
        addObject(red1, 400, 400);
        addObject(green1, 200, 400);
        addObject(blue1, 25, 400);
        addObject(blue2, 200, 500);
        addObject(blue3, 300, 550);
        addObject(blue4, 200, 500);
        
    }
}