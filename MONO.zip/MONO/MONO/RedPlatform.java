import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RedPlatform here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RedPlatform extends Actor
{
    //color in hexa: ff0000
    public void act() 
    {
        // Add your action code here.
    }    
}
