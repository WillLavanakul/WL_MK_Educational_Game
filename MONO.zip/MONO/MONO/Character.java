import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Character here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Character extends Actor
{
    private int vSpeed = 0;
    private Class color = BluePlatform.class;
    private String strColor = "Blue";
    /**
     * 
     * Act - do whatever the Character wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act() 
    {
        checkFall();
        if(Greenfoot.isKeyDown("d")){
            move(5);
        }
        if(Greenfoot.isKeyDown("a")){
            move(-5);
        }
        if ("space".equals(Greenfoot.getKey())) // jump key detected
            {
                vSpeed = -15; // add jump speed
                setLocation(getX(), getY()+vSpeed); // leave ground
            }
    }    
    
    public void setColor(Class c){
        color = c;
    }
    
    public Class getColor(){
        return color;
    }
    
    public void setStrColor(String c){
        strColor = c;
    }
    
    public String getStrColor(){
        return strColor;
    }
    
    public void fall()
    {
        vSpeed++;
        setLocation(getX(), getY() + vSpeed);
    }
    
    public boolean onGround()
    {
        int spriteHeight = getImage().getHeight();
        int lookForGround = (int)(spriteHeight/2) + 5;
        
        Actor ground = getOneObjectAtOffset(0, lookForGround, color);
        if(ground == null){
            return false;
        }
        else{
            return true;
        }
    }
    
    public void checkFall()
    {
        if(onGround()){
            vSpeed = 0;
        }
        else{
            fall();
        }
    }
    
}